unzip to /etc/openclash/core/
